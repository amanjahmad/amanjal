
<?php

session_start();
$array=[

    'log'=>'',
    'class'=>''
];
$userdb='root';
$passdb='';


if(isset($_POST['aamanj'])){

      
     $db=new PDO("mysql:host=localhost;dbname=dates;charset=utf8",$userdb,$passdb);
     $code=$db->prepare("SELECT * FROM  aliamanj WHERE code=:code");
     $code->bindParam("code",$_POST['code']);
     $code->execute();
    
      if($code->rowCount() > 0){
        $updb=$db->prepare("INSERT INTO sing_up(user,emil,pass)VALUES(:name,:mail,:pass)");
        $updb->bindParam("name",$_SESSION['name']);
        $updb->bindParam("mail",$_SESSION['mail']);
        $updb->bindParam("pass",$_SESSION['pass']);
        $updb->execute();
        $array['log']='تم انشاء الحساب بنجاح';
        $array['class']='alert alert-success';
        $ref=' setInterval(()=>{
            location.assign("form.php");
        },3000);';
       
      }


}




?>






<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-+0n0xVW2eSR5OomGNYDnhzAbDsOXxcvSN1TPprVMTNDbiYZCxYbOOl7+AMvyTG2x" crossorigin="anonymous">

    <link rel="stylesheet" href="amanj.css">
    <title>Document</title>
</head>
<body dir="rtl">
 <div class="amanj">
 
<div class="contenar">

<form id="form" method="POST">
 

    
  <div class="mb-3">
    <label for="exampleInputPassword1" class="form-label">رمز التحقق</label>
    <input type="password" class="form-control" id="pass" name="code">
    <p class="errorpass"></p>
  </div>
  
  <button type="submit" class="btn btn-warning" name="aamanj" id="button">تسجيل </button>
  <p class="<?php echo $array['class'];?>" ><?php echo $array['log']; ?></p>
  


</div>
</form>

    <script>
    <?php echo $ref; ?>
    
    </script>
</body>
</html>
