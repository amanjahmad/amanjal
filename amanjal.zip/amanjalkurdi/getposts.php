<?php


session_start();
if($_SESSION['emildb'] === "ghofran@gmail.com" && $_SESSION['namedb'] === "ghofran"){




$userdb='root';
$passdb='';
    
$db=new PDO("mysql:host=localhost;dbname=dates;charset=utf8",$userdb,$passdb);


    
$gethom=$db->prepare("SELECT * from posts");



$gethom->execute();

echo '
<table class="table">
  <thead class="table-dark">
    ...
  </thead>
  <tr>
  <td class="table-dark">name</td>
  <td class="table-dark">emil</td>
  <td class="table-dark">room</td>
  <td class="table-dark">DAYS</td>
  <td class="table-dark">date</td>
  
  </tr>
  <tbody>

';
foreach($gethom as $amanj){
echo '  
<tr>
<td class="table-secondary">'.$amanj['username'].'</td>
<td class="table-secondary">'.$amanj['emil'].'</td>
<td class="table-secondary">'.$amanj['idpost'].'</td>
<td class="table-secondary">'.$amanj['nub'].'</td>
<td class="table-secondary">'.$amanj['date'].'</td>
</tr>
';

}
echo '</tbody>
</table>';
}

else{
    header("location:form.php");
}

    



?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-+0n0xVW2eSR5OomGNYDnhzAbDsOXxcvSN1TPprVMTNDbiYZCxYbOOl7+AMvyTG2x" crossorigin="anonymous">


    <title>Document</title>
</head>
<body>
    
</body>
</html>