<?php


if(isset($_POST['emil'])){
 
    $userdb='root';
    $passdb='';
        
    $db=new PDO("mysql:host=localhost;dbname=dates;charset=utf8",$userdb,$passdb);
    $code=$db->prepare("INSERT INTO posts(emil,nub,date,idpost,username)VALUES(:emil,:nub,CURRENT_DATE,:id,:name)");

    $code->bindParam("emil",$_POST['emil']);
    $code->bindParam("nub",$_POST['nub']);
    $code->bindParam("id",$_POST['room']);
    $code->bindParam("name",$_POST['name']);



    $code->execute();


}

?>