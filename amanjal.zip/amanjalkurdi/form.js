let form=document.getElementById('form');
form.addEventListener('submit',(e)=>{
e.preventDefault();

   
    let mail=document.getElementById('mail').value;
    let pass=document.getElementById('pass').value;

    if( mail == "" || pass == "" ){

        
        if(mail == ""){
          
          document.querySelector('.erroremail').innerHTML="ايميل غير مسجل";
      }
      
      
      if(pass == ""){
         
          document.querySelector('.errorpass').innerHTML="باسورد غير مسجل";
      }
      

    }
    else{
        let xhr=new XMLHttpRequest();
        let up =new FormData();
       
        up.append('mail',mail);
        up.append('pass',pass);
        xhr.onload=paly;
        function paly(){


        
            
              location.assign(xhr.responseText);
        }


        xhr.open("POST","getform.php",true);
        xhr.send(up);








    }

    
});