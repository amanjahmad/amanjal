let form=document.getElementById('form');
form.addEventListener('submit',(e)=>{
e.preventDefault();

    let user=document.getElementById('user').value;
    let mail=document.getElementById('mail').value;
    let pass=document.getElementById('pass').value;

    if(user == "" || mail == "" || pass == "" ){

        if(user == ""){
    
            document.querySelector('.errorname').innerHTML="اسم مستخدم غير مسجل";
        } else{
            document.querySelector('.errorname').innerHTML=""; 
        }
         
        if(mail == ""){
          
          document.querySelector('.erroremail').innerHTML="ايميل غير مسجل";
      }
      
      
      if(pass == ""){
         
          document.querySelector('.errorpass').innerHTML="باسورد غير مسجل";
      }
      

    }
    else{
        let xhr=new XMLHttpRequest();
        let up =new FormData();
        up.append('name',user);
        up.append('mail',mail);
        up.append('pass',pass);
        xhr.onload=paly;
        function paly(){
            let res=xhr.responseText;

            document.getElementById('divmail').innerHTML=`<p class="alert alert-warning"  >${res}</p>`;
            setInterval(()=>{
                location.assign('req.php');
            },3000);
        }


        xhr.open("POST","resolt.php",true);
        xhr.send(up);








    }

    
});