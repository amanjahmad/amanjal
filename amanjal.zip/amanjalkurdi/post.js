

function play(v){

    let name=document.getElementById('name').value;
    let emil=document.getElementById('emil').value;
    let nub=document.getElementById('nub').value;
    



  let xhr=new XMLHttpRequest();
    let up =new FormData();
    up.append('name',name);
    up.append('emil',emil);
    up.append('nub',nub);
    up.append('room',v);
    xhr.onload=paly;
    function paly(){
       
     
        document.querySelector('.h12').style.display='block';
     document.querySelector('.h12').innerHTML='<h2>تم الحجز بنجاح </h2>';
      setTimeout(()=>{

        document.querySelector('.h12').style.display='none';
      },2000);
      
    }
    xhr.open("POST","post.php",true);
    xhr.send(up);







}

