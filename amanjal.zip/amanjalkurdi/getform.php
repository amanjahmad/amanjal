
<?php



if(isset($_POST['mail'])){
 
  $userdb='root';
  $passdb='';
      
  $db=new PDO("mysql:host=localhost;dbname=dates;charset=utf8",$userdb,$passdb);
  $code=$db->prepare("SELECT * FROM  sing_up WHERE emil=:user && pass=:pass");
  $code->bindParam("user",$_POST['mail']);
  $code->bindParam("pass",$_POST['pass']);


  $code->execute();

  if($code->rowCount() > 0){

    
    $gethom=$db->prepare("SELECT * from sing_up where emil=:mail and pass=:pass");
    $gethom->bindParam("mail",$_POST['mail']);
    $gethom->bindParam("pass",$_POST['pass']);


    $gethom->execute();


    $gethom=$gethom->fetchObject();
    if($gethom->admin == 0){

        session_start();
        $_SESSION['namedb']=$gethom->user;
        $_SESSION['iddb']=$gethom->id;
        $_SESSION['emildb']=$gethom->emil;
        echo 'home.php';


    
    }else{


        session_start();
        $_SESSION['namedb']=$gethom->user;
        $_SESSION['iddb']=$gethom->id;
        $_SESSION['emildb']=$gethom->emil;
        echo 'getposts.php';


    }
    
  }
 



}

?>