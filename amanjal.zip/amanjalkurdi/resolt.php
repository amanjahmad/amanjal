<?php
//Import PHPMailer classes into the global namespace
//These must be at the top of your script, not inside a function




    use PHPMailer\PHPMailer\PHPMailer;
    use PHPMailer\PHPMailer\SMTP;
    use PHPMailer\PHPMailer\Exception;

//Load Composer's autoloader
require 'amanjmiler/autoload.php';

//Instantiation and passing `true` enables exceptions

if(isset($_POST['mail'])){




    session_start();
    $_SESSION['name']=$_POST['name'];
    $_SESSION['mail']=$_POST['mail'];

     $_SESSION['pass']=$_POST['pass'];

    $rend=rand(100000,999999);

    $userdb='root';
     $passdb='';
     $db=new PDO("mysql:host=localhost;dbname=dates;charset=utf8",$userdb,$passdb);
     
     $upcdb=$db->prepare("INSERT INTO aliamanj(emil,code)VALUES(:mail,:code)");
     
     $upcdb->bindParam("mail",$_SESSION['mail']);
     $upcdb->bindParam("code",$rend);
      $upcdb->execute();



    $getmail=$_POST['mail'];
$mail = new PHPMailer();

try {
    //Server settings
  //  $mail->SMTPDebug = SMTP::DEBUG_SERVER;                      //Enable verbose debug output
    $mail->isSMTP();                                            //Send using SMTP
    $mail->Host       = 'smtp.gmail.com';                     //Set the SMTP server to send through
    $mail->SMTPAuth   = true;                                   //Enable SMTP authentication
    $mail->Username   = 'ahmadamanj168@gmail.com';                     //SMTP username
    $mail->Password   = 'amanj.12345.12345';                               //SMTP password
    $mail->SMTPSecure = 'ssl';         //Enable TLS encryption; `PHPMailer::ENCRYPTION_SMTPS` encouraged
    $mail->Port       = 465;                                    //TCP port to connect to, use 465 for `PHPMailer::ENCRYPTION_SMTPS` above

    //Recipients
    $mail->setFrom('ahmadamanj168@gmail.com', 'موقع حجز فنادق');
    $mail->addAddress($getmail, 'سعد وقتك');     //Add a recipient
   
    //Attachments
    
    //Content
    $mail->isHTML(true);                                  //Set email format to HTML
    $mail->Subject = 'اضغط على رابط للتفعيل ';
    $mail->Body    = '<h2>رمز تحقق</h2> <br> <p> '. $rend .'</p>' ;
    $mail->AltBody = 'This is the body in plain text for non-HTML mail clients';
    $mail->CharSet="Utf-8";

    $mail->send();
    echo 'تم ارسال رابط التفعيل ';
} catch (Exception $e) {
    echo "Message could not be sent. Mailer Error: {$mail->ErrorInfo}";
}
}
