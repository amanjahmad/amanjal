<?php
session_start();

if(empty($_SESSION['namedb'])){


    header("location:form.php");
}
$userdb='root';
  $passdb='';
      
  $db=new PDO("mysql:host=localhost;dbname=dates;charset=utf8",$userdb,$passdb);
  $get=$db->prepare("SELECT * from post");
  $get->execute();
 
  

?>



<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="home.css">
</head>
<body>
    <div class="h12">  </div>
  
  
  
  
  <?php



   
   echo '

   <input type="hidden" id="name" value="'. $_SESSION['namedb'].'">
   <input type="hidden" id="emil" value="'. $_SESSION['emildb'].'">
   
   ';
   
   foreach($get as $amanj){
    echo '

    
  
    <div class="center">
    
    <div class="div12">


          
       <img src="../img/'. $amanj["imgname"] .'" alt="" srcset="" id="img">
       <button type="submit"   class="but" onclick="play('.$amanj['id'].')" > reservation</button>
       
       
       

       <span>Price</span>
       <span>days</span>
       <span>available</span>
       <span>20$</span>
       <input type="number" min="1" value="2" max="10"  id="nub">
        <span class="a">yse </span>
       
    
    </div>
    </div>
  
';

   }


   
   ?>




   <script src="post.js"></script>

</body>
</html>