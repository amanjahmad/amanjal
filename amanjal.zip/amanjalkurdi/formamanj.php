<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
  
    <!-- CSS only -->
   

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-+0n0xVW2eSR5OomGNYDnhzAbDsOXxcvSN1TPprVMTNDbiYZCxYbOOl7+AMvyTG2x" crossorigin="anonymous">

<link rel="stylesheet" href="amanj.css">


    <title>Document</title>
</head>


<body dir="rtl">
 <div class="amanj">
 
<div class="contenar">

<form id="form">
  
<div class="mb-3">
    <label for="exampleInputEmail1" class="form-label"> اسم الامستخدم</label>
    <input type="text" class="form-control" id="user" aria-describedby="emailHelp">
       <p class="errorname"></p>
   
  </div>

 
  <div class="mb-3">
    <label for="exampleInputEmail1" class="form-label">ايميل</label>
    <input type="email" id="mail"  class="form-control" aria-describedby="emailHelp" >
    <p class="erroremail"></p>
    
  </div>
  <div class="mb-3">
    <label for="exampleInputPassword1" class="form-label">رمز</label>
    <input type="password" class="form-control" id="pass">
    <p class="errorpass"></p>
  </div>
  
  <button type="submit" class="btn btn-warning" id="button">تسجيل حساب</button>
  <a href="form.php"  class="btn btn-outline-warning a">لدي حساب</a> 
 <div id="divmail">

</div>
</form>


</div>
</div>




<table class="table">
  <thead class="table-dark">
    ...
  </thead>
  <tbody>
    <tr>
    <td class="table-dark">...</td>
    <td class="table-dark">...</td>
    <td class="table-dark">...</td>
    <td class="table-dark">...</td>
    
    
    </tr>

    <td class="table-secondary">...</td>
    <td class="table-secondary">...</td>
    <td class="table-secondary">...</td>
    <td class="table-secondary">...</td>

  </tbody>
</table>


 <!-- JavaScript Bundle with Popper -->

<script src="ajaxamanj.js"></script>


</body>
</html>